from ZhaoyuMotifGraph import calculation
from ZhaoyuMotifGraph import motif_graph


name = 'ZhaoyuMotifGraph'

